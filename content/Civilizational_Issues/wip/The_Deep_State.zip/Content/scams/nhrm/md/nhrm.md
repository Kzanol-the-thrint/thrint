# Overview

## Question
 Red Flags Worth Scrutiny (Circumstantial, not Confirmed)
34.	1. NRHM Scam Period – Early 2010s
•	The National Rural Health Mission (NRHM) scam in Uttar Pradesh saw bureaucrats, politicians, and alleged fixer networks siphon off thousands of crores.
•	Sehgal’s name came up tangentially, as a then-senior officer in the UP bureaucracy.
o	Some whistleblowers claimed he had knowledge of systemic misuse, but he was never named as an accused.
o	Multiple senior officials (e.g., Pradeep Shukla, B.P. Yadav) were jailed.
o	At least 5 officials and medical officers were found dead under suspicious circumstances, believed by many to be mafia-style silencing.
Inference: While no FIR or CBI inquiry named him, his proximity to those involved in the scam has drawn whispers of complicity or passive facilitation.
________________________________________
what was the NHRM and which government was in power

## **What Was the NRHM Scam?**

The **NRHM Scam** refers to massive corruption in the implementation of the **National Rural Health Mission (NRHM)** in **Uttar Pradesh** during the **2005–2012** period. The scam involved **embezzlement of thousands of crores** meant for improving healthcare infrastructure in rural areas — including funds for primary health centers, medical equipment, training programs, and maternal-child health schemes.

---

## **About NRHM**

* **Launched by**: UPA Government (Manmohan Singh) in **2005** under the Ministry of Health and Family Welfare.
* **Objective**: Improve access to quality healthcare for **rural populations**, especially women and children.
* **Implementation**: Delegated to state governments with significant **discretionary powers** in fund allocation and project execution.

---

## **Nature of the Scam**

* Massive irregularities in:

  * Procurement of medical equipment
  * Civil construction contracts
  * Staff hiring and training payments
  * Fund disbursement through fictitious or inflated invoices
* **Murder and silencing**:

  * At least **5 deaths** under suspicious circumstances, including:

    * **Dr. Vinod Arya**, **Dr. B.P. Singh** – former CMOs of Lucknow
    * **Dr. Y.S. Sachan** – Deputy CMO found dead in jail under mysterious conditions
* These deaths were suspected to be part of a **mafia-style cover-up** to prevent exposure of the racket.

---

## **Government in Power (UP)**

| Period    | Chief Minister          | Party                         |
| --------- | ----------------------- | ----------------------------- |
| 2002–2007 | **Mulayam Singh Yadav** | **Samajwadi Party (SP)**      |
| 2007–2012 | **Mayawati**            | **Bahujan Samaj Party (BSP)** |

The **bulk of the scam unfolded under Mayawati’s rule (2007–2012)**, though irregularities began earlier during the SP regime.

---

## **Key Accused and Convictions**

* **Pradeep Shukla (IAS)** – Principal Secretary (Health), jailed
* **B.P. Yadav** – Executive Engineer, jailed
* Dozens of contractors, CMOs, and bureaucrats investigated
* Investigated by:

  * **CBI**
  * **Enforcement Directorate**
  * **UP Police Special Task Force**

---

## **Navneet Sehgal's Role**

* Not a named accused.
* Held senior secretariat-level roles during the period.
* His **association with the Information Department and proximity to CM’s office** placed him close to the administrative structure that allegedly allowed the scam to flourish.
* **Whistleblowers claimed** he “must have known” about the systemic diversion of funds — though **no concrete evidence has emerged**.

---

## Summary

* **NRHM** was a Central Government (UPA) scheme.
* **Execution and scam** occurred under UP state governments — primarily **BSP (Mayawati)**.
* The scandal reflects a **breakdown in checks and balances**, and a **potential deep state-like nexus** of bureaucrats, politicians, contractors, and enforcers.
* Navneet Sehgal’s **proximity to the power center**, though legally clean, positions him as a **person of interest** in circumstantial assessments.

Would you like a tabular breakdown of all named accused and deceased officials in the NRHM scam?
