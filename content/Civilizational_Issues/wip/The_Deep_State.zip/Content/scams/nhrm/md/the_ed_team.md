# The ED Team

## Question
the ED team

[![Enforcement Directorate attaches properties worth Rs 200 crore in NRHM ...](https://tse1.mm.bing.net/th?id=OIP.tiPI0hJ_1Y6dTOUxk_TuKwHaEB\&pid=Api)](https://timesofindia.indiatimes.com/india/Enforcement-Directorate-attaches-properties-worth-Rs-200-crore-in-NRHM-scam/articleshow/49083754.cms)

The Enforcement Directorate (ED) played a pivotal role in investigating the National Rural Health Mission (NRHM) scam in Uttar Pradesh, focusing on money laundering aspects under the Prevention of Money Laundering Act (PMLA).

## Key ED Officers Involved

* **Rajeshwar Singh**: As the Joint Director of the ED's Lucknow Zonal Office, Singh spearheaded several investigations related to the NRHM scam. Under his leadership, the ED attached properties worth ₹23.54 crore linked to the former Managing Director of the Uttar Pradesh Small Industries Corporation (UPSIC) and associated suppliers involved in the misappropriation of NRHM funds. ([The Times of India][1])

## ED's Investigative Actions

* **Attachment of Assets**: The ED attached assets valued at approximately ₹196 crore belonging to Babu Singh Kushwaha, a former Uttar Pradesh Minister, for his alleged involvement in laundering proceeds from the NRHM scam. ([www.ndtv.com][2])

* **Provisional Attachments**: In March 2025, the ED provisionally attached movable and immovable properties worth ₹89.84 lakh under the PMLA, targeting assets of individuals and entities implicated in the scam. ([ABP Live][3])

* **Nationwide Raids**: The ED conducted nationwide raids against government officials facing corruption charges, including those allegedly part of the NRHM scam, leading to the attachment of proceeds of crime exceeding ₹250 crore. ([Hindustan Times][4])

These actions underscore the ED's commitment to unraveling the financial intricacies of the NRHM scam and holding accountable those involved in the misappropriation of public funds.

If you require further details on specific cases or individuals involved, feel free to ask.

[1]: https://timesofindia.indiatimes.com/city/lucknow/ed-attaches-property-of-upsic-ex-md-in-nrhm-scam/articleshow/58038025.cms?utm_source=chatgpt.com "ED attaches property of UPSIC ex-MD in NRHM scam | Lucknow News"
[2]: https://www.ndtv.com/india-news/nrhm-scam-enforcement-directorate-attaches-ex-ministers-assets-worth-rs-196-crore-1220982?utm_source=chatgpt.com "NRHM Scam: Enforcement Directorate Attaches Ex-Minister's Assets ..."
[3]: https://news.abplive.com/cities/what-s-up-nrhm-scam-inside-health-scheme-swindle-behind-ed-s-massive-rs-90-lakh-seizure-abp-decodes-1756851?utm_source=chatgpt.com "ED Attaches Assets Worth Lakhs in UP's NRHM Scam - ABP Live"
[4]: https://www.hindustantimes.com/india-news/ed-conducts-nationwide-raids-against-govt-officials-facing-corruption-charges/story-VYp3XvJrbIWVm3J1CflBtI.html?utm_source=chatgpt.com "ED conducts nationwide raids against govt officials facing corruption ..."
