# CAG Report

## Question
are there any CAG reports related to this matter -
https://cag.gov.in/en/audit-report/details/9303?utm_source=chatgpt.com



[![Uttar Pradesh NRHM Scam | Download Free PDF | Government Of India ...](https://tse2.mm.bing.net/th/id/OIP.vKp_fwMqG9TuYRm3nGZu0AHaJ4?pid=Api)](https://www.scribd.com/document/173312901/Uttar-Pradesh-NRHM-scam-doc)

Yes, the Comptroller and Auditor General (CAG) of India conducted a comprehensive audit of the National Rural Health Mission (NRHM) in Uttar Pradesh, revealing significant financial irregularities.

## Key Findings from the CAG Audit

* **Unaccounted Funds**: Approximately ₹4,900 crore of NRHM funds were unaccounted for between April 2005 and March 2011. The state health department failed to provide proper documentation for these expenditures. ([Hindustan Times][1])

* **Discrepancies in Receipts**: A difference of ₹358.18 crore was noted between the funds received from the Government of India and the amount acknowledged by the State Health Society (SHS). Additionally, ₹1,768.12 crore received through the treasury route was not reflected in SHS accounts. ([The Times of India][2])

* **Lack of Monitoring and Evaluation**: The audit highlighted the absence of monitoring or evaluation by the state government. The internal audit mechanism was found to be defunct, and senior officials did not examine NRHM records. ([Hindustan Times][1])

* **Irregularities in Procurement**: Contracts worth ₹1,170 crore were awarded without following the open tendering process, flouting established norms. Only one officer of the Principal Secretary rank was making crucial purchase decisions, contrary to the requirement of a committee comprising multiple officers. ([India Today][3])

* **Inflated Expenditure and Non-Utilization**: The report pointed out inflated expenditure and non-utilization of ₹1,243.63 crore by the health department. Funds were allocated without finalizing plans for procurement of equipment and construction works. ([The Economic Times][4])

## Accessing the Full Report

The detailed CAG audit report titled "Performance Audit on National Rural Health Mission of Government of Uttar Pradesh" was tabled on May 30, 2012. It is available for download on the official CAG website: ([CAG][5])([CAG][5])

If you need assistance in analyzing specific sections of the report or require a summary of particular findings, feel free to ask.

[1]: https://www.hindustantimes.com/lucknow/cag-puts-rs4-900-cr-tag-on-up-health-scam/story-2YaLD2CmhSXZx0tjTFGdiP.html?utm_source=chatgpt.com "CAG puts Rs4,900-cr tag on UP health scam - Hindustan Times"
[2]: https://timesofindia.indiatimes.com/india/cag-reports-massive-health-scam-in-up/articleshow/13673499.cms?utm_source=chatgpt.com "CAG reports massive health scam in UP - Times of India"
[3]: https://www.indiatoday.in/india/north/story/nrhm-scam-cag-finds-anomalies-in-spending-of-about-rs-5000-crore-90458-2012-01-20?utm_source=chatgpt.com "NRHM scam: Anomalies in spending of Rs 5,000 cr - India Today"
[4]: https://m.economictimes.com/cag-points-anomalies-in-up-health-dept-expenses/articleshow/9539837.cms?utm_source=chatgpt.com "CAG points anomalies in UP health dept. expenses"
[5]: https://cag.gov.in/en/audit-report/details/9303?utm_source=chatgpt.com "Audit Reports | Comptroller and Auditor General of India"
