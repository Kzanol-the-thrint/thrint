# CBI Judges and IOs

## Question
who were the cbi court judges , and the CBI IOs


Based on available information, the following key individuals were involved in the investigation and adjudication of the National Rural Health Mission (NRHM) scam in Uttar Pradesh:

---

## CBI Court Judges

1. **Justice A.K. Singh**
   Served as the Special CBI Judge at Ghaziabad, presiding over several NRHM scam cases, including the first chargesheet filed in April 2012. 

2. **Justice Shyam Lal**
   Appointed as the Second Special Judge, Anti-Corruption, CBI, Ghaziabad, designated to handle NRHM scam matters across Uttar Pradesh. 

3. **Justice Rekha Dikshit**
   As a Special Judge in Lucknow, she presided over CBI Special Court proceedings related to the NRHM scam. 

---

## CBI Investigating Officers

While specific names of the CBI Investigating Officers (IOs) involved in the NRHM scam are not publicly disclosed, the investigation was overseen by the CBI under the direction of then CBI Director Ranjit Sinha. ([Hindustan Times][1])

---

If you require further details or information on specific aspects of the NRHM scam investigations, please let me know.

[1]: https://www.hindustantimes.com/india/nrhm-scam-probe-is-now-cbi-s-biggest-investigation/story-ew43mwdPNoFAo9gSoXTPZI.html?utm_source=chatgpt.com "NRHM scam probe is now CBI's biggest investigation"
