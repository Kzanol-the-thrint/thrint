# ED Attachments

## Question
“You don’t move ₹10,000 crore through a state department unless the top netas are either sleeping—or eating.”
— Retired UP CAG officer (anonymous), 2015

what was the total amount attached in UP and rest of India [except India] only related to the NHRM scam



[![NRHM scam: ED attaches assets of ex-UP minister Kushwaha – India TV](https://tse2.mm.bing.net/th?id=OIP.TLl9rX9ZGibR6LWPfyG3PAHaFM\&pid=Api)](https://www.indiatvnews.com/news/india/nrhm-scam-ed-attaches-assets-of-ex-up-minister-kushwaha-35073.html)

The Enforcement Directorate (ED) has conducted multiple asset attachments in connection with the National Rural Health Mission (NRHM) scam in Uttar Pradesh. The most significant attachment was in 2015, when the ED attached properties worth approximately ₹200 crore linked to former Uttar Pradesh Family Welfare Minister Babu Singh Kushwaha. ([The Times of India][1])

In addition to this, the ED has made several other attachments:

* In March 2025, assets valued at ₹89.84 lakh were attached, targeting properties of individuals involved in the misuse of NRHM funds. ([ABP Live][2])

* In December 2024, properties worth approximately ₹68.47 lakh were attached in connection with the scam. ([The Times of India][3])

* In September 2016, the ED attached assets worth over ₹23 crore related to a medical firm implicated in the NRHM scam. ([DNA India][4])

These figures indicate that the total value of assets attached by the ED in connection with the NRHM scam in Uttar Pradesh exceeds ₹223 crore.

Regarding the NRHM scam in other states, such as Jharkhand, the ED has also taken action. In one instance, the agency attached properties worth over ₹3.5 crore linked to individuals involved in the misappropriation of NRHM funds. ([Ommcom News][5])

While these figures provide insight into the ED's actions, it's important to note that the total amount misappropriated in the NRHM scam is estimated to be significantly higher, with some reports suggesting that over ₹5,000 crore were siphoned off in Uttar Pradesh alone. 

If you would like a detailed breakdown of these attachments or further information on specific cases, feel free to ask.

[1]: https://timesofindia.indiatimes.com/india/enforcement-directorate-attaches-properties-worth-rs-200-crore-in-nrhm-scam/articleshow/49083754.cms?utm_source=chatgpt.com "Enforcement Directorate attaches properties worth Rs 200 crore in ..."
[2]: https://news.abplive.com/cities/what-s-up-nrhm-scam-inside-health-scheme-swindle-behind-ed-s-massive-rs-90-lakh-seizure-abp-decodes-1756851?utm_source=chatgpt.com "ED Attaches Assets Worth Lakhs in UP's NRHM Scam - ABP Live"
[3]: https://timesofindia.indiatimes.com/city/lucknow/ed-probes-nrhm-fund-misuse-attaches-assets-worth-rs-68-lakh/articleshow/116057058.cms?utm_source=chatgpt.com "ED attaches Rs 68 lakh worth assets in NRHM fund misuse case"
[4]: https://www.dnaindia.com/business/report-nrhm-scam-ed-attaches-rs-23-cr-assets-of-medical-firm-2382714?utm_source=chatgpt.com "NRHM scam: ED attaches Rs 23 cr assets of medical firm - DNA India"
[5]: https://ommcomnews.com/india-news/ed-attaches-more-properties-of-ramapati-devi-in-jharkhands-nrhm-scam/?utm_source=chatgpt.com "ED Attaches More Properties Of Ramapati Devi In Jharkhand's ..."
