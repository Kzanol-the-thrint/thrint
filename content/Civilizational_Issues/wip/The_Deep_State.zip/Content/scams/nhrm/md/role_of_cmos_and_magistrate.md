# The Role of CMOs and Magistrates

## Question
yes - but later - we need add a few pieces
what is the role of the CMOs and Majistrates

Excellent — before we build the full mafia-style network chart later, it's crucial to understand the **roles of CMOs (Chief Medical Officers)** and **District Magistrates (DMs)** in the **NRHM scam structure**, as they were the **operational lynchpins** through which the funds were siphoned.

---

## **Role of CMOs (Chief Medical Officers)**

**Position**: Head of District Health Services under NRHM

### Key Powers:

* Authorized **release of NRHM funds** at the district level
* Sanctioned **purchases of medicines, ambulances, training kits, and construction projects**
* Oversaw **contracts with private vendors** and construction contractors
* Issued **utilization certificates (UCs)** to justify spending — often forged
* Could recommend appointments of auxiliary health staff under NRHM schemes

### Role in Scam:

* CMOs were the **front-line enablers** of the fraud
* Created **ghost purchases**, approved **inflated invoices**
* Often acted in collusion with **contractors and health department engineers**
* Several CMOs were **murdered** or **found dead** after being suspected whistleblowers or financial links

| Notable CMOs             | Fate                      | Significance                              |
| ------------------------ | ------------------------- | ----------------------------------------- |
| Dr. Vinod Arya           | Shot dead (2010)          | Allegedly refused to sign inflated bills  |
| Dr. B.P. Singh           | Shot dead (2011)          | Linked to fraudulent construction tenders |
| Dr. Y.S. Sachan (Dy CMO) | Found dead in jail (2011) | Believed to be about to expose network    |

---

## **Role of District Magistrates (DMs) / Joint Magistrates**

**Position**: Administrative head of the district (IAS officer)

### Key Powers:

* Final **sign-off authority** for large procurement packages
* Oversaw the **District Health Society** — where NRHM funds were parked
* Could **appoint auditors**, approve annual health plans, and oversee construction works
* Chaired **NRHM implementation review meetings** — formally responsible for oversight

### Role in Scam:

* Many DMs acted as **rubber stamps** — signing off on clearly suspicious tenders
* Allegedly received **“cuts” or political pressure** to approve files
* In some cases, **looked the other way** while their CMO colluded with mafia contractors
* A few DMs raised alarms but were **transferred or silenced**

| Common Pattern         | Reality                                  |
| ---------------------- | ---------------------------------------- |
| “Not in our knowledge” | Files were routed via them regularly     |
| “Oversight lapse”      | In many cases, lapses were intentional   |
| “Political pressure”   | Credible; DMs were puppets in many areas |

---

## **How CMOs and DMs Fit Into the Scam Hierarchy**

```plaintext
POLITICAL BOSSES (CM / Ministers like Kushwaha)
        │
    Bureaucratic “Fixers” (e.g., Pradeep Shukla)
        │
District Magistrate (approves, protects)
        │
Chief Medical Officer (executes payments, appoints vendors)
        │
Engineers / Clerks / Contractors (submit fake bills)
```

---

Would you like to now:

* Add specific **names of DMs or IAS officers** who served in scam-heavy districts (Lucknow, Kanpur, Meerut)?
* Or proceed to the **Mafia-style org chart** once you’re ready?

