# The Single Principal Secretary Making Purchase Decisions

## Question
Only one officer of the Principal Secretary rank was making crucial purchase decisions - name and status - was he convicted

[![Ex-UP health secy held in NRHM scam - India Today](https://tse1.mm.bing.net/th?id=OIP.DkZSzxrBKYQ0TKUwd85wBgHaEK\&pid=Api)](https://www.indiatoday.in/india/north/story/nrhm-scam-ex-uttar-pradesh-health-secretary-pradeep-shukla-held-101803-2012-05-10)

The senior IAS officer who served as Principal Secretary (Health and Family Welfare) in Uttar Pradesh during the National Rural Health Mission (NRHM) scam was **Pradeep Shukla**. He was arrested by the Central Bureau of Investigation (CBI) in May 2012 for his alleged involvement in the misappropriation of NRHM funds. ([The Times of India][1])

According to CBI investigations, Shukla received approximately ₹4.5 crore in bribes to manipulate contracts, notably awarding a ₹26.66 crore contract to Surgicoin Equipment Pvt Ltd for upgrading 36 hospitals. The work was allegedly done at inflated rates, causing significant losses to the exchequer. ([The Times of India][1])

In December 2022, a special court summoned Pradeep Shukla, along with former minister Babu Singh Kushwaha and others, to face trial under the Prevention of Money Laundering Act (PMLA) for their roles in the NRHM scam. ([Hindustan Times][2])

As of now, the trial proceedings are ongoing, and a final conviction or acquittal has not been reported.

If you would like more detailed information on the charges or the current status of the trial, please let me know.

[1]: https://timesofindia.indiatimes.com/india/nrhm-scam-shukla-received-4-5cr-to-manipulate-contract/articleshow/13103533.cms?utm_source=chatgpt.com "NRHM scam: Shukla received 4.5cr to manipulate contract"
[2]: https://www.hindustantimes.com/cities/lucknow-news/nrhm-scam-court-summons-ex-bsp-minister-former-ias-three-others-to-face-trial-101671645180030.html?utm_source=chatgpt.com "NRHM scam: Court summons ex-BSP minister, former IAS,three ..."
