# **Chapter 3: Navneet Sehgal – Archetype of the Hidden Ruler**

In a nation where elected representatives derive their power from the ballot box and ministers from parliamentary majorities, Navneet Sehgal draws his strength from an entirely different source—his entrenchment within the bureaucratic deep state.

A 1988-batch IAS officer of the Uttar Pradesh cadre, Sehgal has served under successive Chief Ministers representing rival ideologies: Mulayam Singh Yadav (Samajwadi Party), Mayawati (Bahujan Samaj Party), Akhilesh Yadav (SP), and Yogi Adityanath (BJP). His ability to seamlessly traverse these vastly divergent political dispensations is not a coincidence. It is the defining mark of the Indian deep state—a structure that sustains its relevance through **continuity, concealment, and utility**.

Sehgal’s career portfolio spans the most sensitive and influential departments in the state: information and public relations, infrastructure and industrial development, MSMEs, and now national media via Prasar Bharati. These are not mere administrative roles—they are control points for narrative, capital, and public perception.

His appointment as **Chairman of Prasar Bharati**, India’s autonomous public broadcaster, places him at the apex of government-controlled information dissemination. Unlike private media moguls, Sehgal operates with **state legitimacy, bureaucratic insulation, and zero public accountability**. He does not need to earn ratings or advertising revenue. His power flows from **invisible channels**: bureaucratic selection, political convenience, and strategic silence.

More than any police officer or politician, Sehgal epitomizes the **unseen India**—the real India. He is not answerable to the electorate. He is not interrogated by the press. He is not bound by term limits. And yet, he shapes more policy, controls more funds, and filters more narratives than most ministers.

Even powerful elected figures like the Home Minister or Chief Minister are temporally bound—they must win elections and serve under the scrutiny of courts, voters, and party rivals. Sehgal is subject to none of these. He represents the **invisible constitutional order** that outlives all regimes: the file-pushing, narrative-shaping, patronage-controlling regime of senior bureaucracy.

To call him a 'fixer' is to diminish his function. To call him a 'civil servant' is to understate his autonomy. He is **India’s bureaucratic cardinal**, operating behind velvet curtains, his fingerprints on documents, but his name rarely on record.

In geopolitical terms, Navneet Sehgal is the **perfect bureaucrat for a post-democratic republic**—untouched by ideology, untethered by scrutiny, and unbothered by transparency.

He is not the exception. He is the prototype.
