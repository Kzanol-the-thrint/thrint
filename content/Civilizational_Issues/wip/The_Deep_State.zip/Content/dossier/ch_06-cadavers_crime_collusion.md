# **Chapter 6: Cadavers, Crime, and Collusion – A National Pattern of Signature Suppression**

Beyond white-collar corruption lies a darker architecture: the systematic elimination of witnesses, whistleblowers, and inconvenient bodies. India’s deep state does not only steal silently—it silences violently. This chapter explores a chilling national pattern that connects state-enabled cover-ups across regions, professions, and political cycles.

### 1. RG Kar Medical College (West Bengal)

* A young woman was raped and murdered within the premises of a premier medical institution.
* The crime scene was sanitized; forensic inconsistencies were buried.
* Police filed misleading FIRs. The judiciary advised the victim’s parents to “approach the High Court”—a euphemism for procedural euthanasia.
* Public protest was stifled. Doctors were coerced into silence.

### 2. Sushant Singh Rajput & Disha Salian (Mumbai)

* Bollywood star Sushant Singh’s death was officially deemed suicide—despite contradictory forensic markers.
* Disha Salian, his former manager, died days earlier under suspicious circumstances.
* CCTV footage disappeared. Police refused a second autopsy. Narrative control was absolute.
* Media deflected attention via sensationalism and discrediting campaigns.

### 3. Akshat Shah (Surat Techie)

* A young software engineer was found dead under circumstances the police called “accidental.”
* No thorough post-mortem, no proper FIR, and no public investigation.
* Family and colleagues faced social pressure to stay silent.
* The IT ecosystem and local administration maintained a coordinated hush.

### 4. NRHM Scam Witnesses (Uttar Pradesh)

* Multiple Chief Medical Officers and key bureaucrats died “mysteriously.”
* One died in jail custody—suggesting IPS-level collusion.
* No meaningful convictions; no court acknowledged a systemic pattern.

### The Pattern: Signature Suppression Techniques

* **Sanitized crime scenes**
* **Pre-written police narratives**
* **Forensic tampering and manipulated autopsies**
* **Judicial inertia or complicity**
* **Media noise to drown dissent**
* **Administrative coercion of survivors and family**

This is not incompetence. It is design.

These are not isolated events. They are part of a larger state machinery to eliminate friction points—whistleblowers, victims, dissenters, and even well-known public figures—if their continued existence threatens the invisible power equilibrium.

No politician has been held accountable in any of the cases above. No bureaucrat punished. No IPS officer dismissed. The State protects itself, not the citizen.

India’s problem is not lawlessness. It is **calibrated law enforcement—used as a weapon of silence.**
