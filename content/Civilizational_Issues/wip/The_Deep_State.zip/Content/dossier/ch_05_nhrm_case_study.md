# **Chapter 5: The NRHM Scam – A Case Study in Invisible Loot**

The National Rural Health Mission (NRHM) was launched in 2005 to provide accessible, affordable, and quality healthcare to the rural poor. In Uttar Pradesh, it became a model not of public health transformation but of institutionalized plunder. The scam, conservatively estimated by the CAG at ₹5,000 crore, remains one of the most elaborate and least prosecuted thefts of public funds in Indian history.

The operational model was simple: inflate procurement costs, bypass tenders, route funds through ghost NGOs, and ensure systemic silence through bribes and elimination.

Only ₹223 crore worth of assets were ever attached by the Enforcement Directorate (ED). The Central Bureau of Investigation (CBI) launched over 70 FIRs, but the prosecutions were limited, carefully targeted, and disproportionate to the scale. Pradeep Shukla, then Principal Secretary (Health), was accused of receiving ₹4.5 crore in bribes—just 0.09% of the total scam value.

More disturbingly, a string of deaths accompanied the scam:

* Medical officers and CMOs were assassinated.
* Key witnesses died in ‘road accidents’ or ‘suicides’.
* One suspect was found dead inside jail—implying direct IPS collusion.

Judicial and investigative complicity was routine:

* Courts accepted weak charge sheets.
* IPS officials overseeing the scam were never prosecuted.
* IAS officers close to the scandal, like Navneet Sehgal, were never named.

The scam’s design ensured plausible deniability and bureaucratic dispersion. Funds were routed through multiple layers of SHS (State Health Society) and district officers. No single signature trail led back to the top. But all paths led to a culture of criminal silence.

A few middlemen and vendors were sacrificed. The architects remained invisible. Political figures—across parties—stayed untouched.

The NRHM scam exemplifies how India’s deep state protects its own:

* The IAS ensures procedural legitimacy.
* The IPS neutralizes whistleblowers.
* The judiciary sanitizes outcomes.
* The ED and CBI perform symbolic enforcement.
* The media is flooded with bigger distractions.

The result? A stolen ₹5,000 crore, a dozen dead, zero systemic reform—and a signal to all future looters that **if done bureaucratically, theft is not a crime—it is governance.**
