# **Chapter 7: Judiciary, Collegium, and Legal Capture**

India’s judiciary is often described as the last bastion of hope. In reality, it is a fortress of discretion—armed with opacity, patronage, and immunity from scrutiny. This chapter explores how judicial structures, particularly the collegium system, have helped insulate systemic abuse, legitimize institutional violence, and normalize the unaccountability of India’s administrative and political elite.

### 1. The Collegium as an Opaque Aristocracy

* Judges in India appoint themselves through the collegium—an extra-constitutional mechanism not mentioned in the Constitution.
* There is no transcript, no formal vetting, and no citizen participation in judicial appointments.
* This has created a **self-selecting, self-perpetuating elite**, which is answerable neither to the people nor to Parliament.

### 2. Procedural Chicanery in Landmark Cases

* In high-stakes cases involving state complicity (e.g., NRHM Scam, RG Kar rape-murder, real estate–crime nexus), courts often cite **procedural insufficiency** or **lack of locus** to avoid substantive intervention.
* PILs are dismissed on technicalities. Evidence is termed 'inadmissible'. Investigations are handed to CBI—knowing the outcome will be slow or inconclusive.

### 3. The Real Estate Ruling: A Moment of Truth

* In an unprecedented move, the Supreme Court acknowledged the existence of a builder-banker-crime syndicate operating in Delhi NCR.
* This should have led to a national probe. Instead, the matter was framed narrowly and never escalated to systemic reform.
* Such acknowledgments are symbolic—meant to preserve legitimacy, not trigger justice.

### 4. The Judiciary and Bureaucracy: A Quiet Partnership

* Judges rarely indict senior IAS or IPS officers.
* The bureaucracy, in turn, ensures post-retirement sinecures for judges: tribunals, commissions, and arbitrations.
* **Mutual non-interference has become mutual reinforcement.**

### 5. The Illusion of Judicial Activism

* Selective activism in cultural or social matters (firecrackers, dress codes, slogans) masks judicial inertia in cases of corruption, state violence, or systemic abuse.
* Media trials present the judiciary as heroic. In reality, critical cases often disappear into procedural black holes.

### Conclusion: Institutional Capture

The Indian judiciary is not neutral—it is **strategically passive**, selectively interventionist, and structurally incapable of confronting the deep state. Far from being a check on executive and bureaucratic overreach, it has become a buffer—**absorbing public anger while deflecting real accountability.**

Justice is not blind. It is bound—in protocol, patronage, and preservation.
