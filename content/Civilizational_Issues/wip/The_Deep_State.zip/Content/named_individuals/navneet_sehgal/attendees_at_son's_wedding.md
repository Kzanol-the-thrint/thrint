# Attendees at His Sons Wedding Reception

## Question
who from the corporate world attended his sons wedding

[![Anirudh and Avni Jain's grand wedding reception- The Etimes ...](https://tse4.mm.bing.net/th?id=OIP.DXfx8eFQL6N62Wj04maz2QHaIc\&pid=Api)](https://photogallery.indiatimes.com/yearendershow/69093816.cms)

At the recent wedding reception of Navneet Sehgal’s son in Lucknow, the event was notably attended by prominent political figures, including:

* **Yogi Adityanath** – Chief Minister of Uttar Pradesh
* **Akhilesh Yadav** – Samajwadi Party chief
* **Satish Mishra** – Bahujan Samaj Party general secretary
* **Aradhna Mishra** – Congress Legislature Party leader

While these political leaders' presence was well-documented, specific details about attendees from the corporate sector are not publicly available in the provided sources. Given Navneet Sehgal’s extensive connections with both political and business communities, it's plausible that notable corporate figures were present at the event. However, without concrete evidence or official guest lists, we cannot confirm the identities of any corporate attendees.

If you're interested in exploring potential corporate associations or seeking information on specific individuals, please provide more details, and I can assist further.
