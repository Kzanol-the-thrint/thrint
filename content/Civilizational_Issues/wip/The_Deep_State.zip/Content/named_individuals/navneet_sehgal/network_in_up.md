# Network Map in UP
**CONFIDENTIAL INTELLIGENCE DOSSIER**

**Subject**: Navneet Kumar Sehgal, IAS (Retd.)
**Alias**: N/A
**Date of Birth**: [Not Publicly Disclosed]
**Batch/Cadre**: 1988, Uttar Pradesh Cadre
**Current Role**: Chairman, Prasar Bharati (India's Public Service Broadcaster)

---

## OVERVIEW

Navneet Sehgal is a retired IAS officer known for his long-standing political survivability across party lines, his mastery of media and information control, and his influence over bureaucratic and corporate ecosystems in Uttar Pradesh and beyond. As of 2025, he is widely regarded as a powerful "silent operator" in India's informal governance architecture.

---

## KEY ROLES HELD

| Period       | Role/Department                                   | Notable Influence                                               |
| ------------ | ------------------------------------------------- | --------------------------------------------------------------- |
| ~1990s–2000s | District Administration & Early Secretariat Roles | Undisclosed — potential proximity to regional intelligence arms |
| 2012–2017    | Principal Secretary, Information (UP Govt)        | Controlled state narrative during SP regime                     |
| 2017–2022    | Principal Secretary, MSME, Tourism, Information   | Directed flagship programs: ODOP, UP Investors Summit           |
| 2022–Present | Chairman, Prasar Bharati                          | National media influence; narrative coordination                |

---

## PROXIMITY TO POLITICAL POWER

* Served under SP (Mulayam & Akhilesh), BSP (Mayawati), and BJP (Yogi Adityanath).
* Coordinated directly with Chief Ministers and Union Ministers.
* Recent high-profile wedding attended by Yogi, Akhilesh, Aradhna Mishra (Congress), and Satish Mishra (BSP).

---

## LINKS TO THE IPS (U.P. Cadre)

**Direct Evidence**: Limited in public domain.

**Circumstantial Indicators**:

* Served in capacities (Information, Home, Culture) where police-PR coordination is key.
* Was part of sensitive event management like Kumbh Mela, Ayodhya Corridor—requiring coordination with DGP, IG zones, and local SPs.
* Known to have managed narratives in riot-like or law-and-order situations (e.g., Hathras, CAA Protests) where IPS officers were active stakeholders.
* Reputed to have **favored police officers who were "narrative compliant"** and helped stall negative press.

**Insider View**: Considered an operator who could indirectly influence **transfers/postings** by lobbying with CM's Office in concert with IPS faction heads.

---

## LINKS TO INTELLIGENCE BUREAU (IB)

**Direct Evidence**: Not available in public sources.

**Operational Inference**:

* As Prasar Bharati Chief, indirectly engages with MIB, MHA, and possibly IB desks overseeing media surveillance.
* Coordinated election-time information control—overlapping with IB's internal threat assessments.
* Trusted by **both secular and right-wing regimes** — suggesting **vetting and clearance at central intelligence level**.
* **No record of surveillance or obstruction** by IB during sensitive tenures implies either:

  * IB views him as an asset or stabilizer, or
  * IB was instructed to steer clear.

**Hypothesis**: May not be an officer within IB networks, but likely acts as a **trusted civilian proxy for strategic information management**, especially when managing religious, communal, or political sensitivities.

---

## LINKS TO CORPORATES

* Spearheaded UP Investors Summits; direct engagement with Reliance, Adani, Infosys, etc.
* Handled massive state advertisement budgets; possible soft power over media conglomerates.
* Associated with UP land development and tourism contracts — sectors known to have real estate-crime-corporate nexus.

---

## CONTROVERSIES / RED FLAGS

* **NRHM Scam Era (2009–2012)**: Though never indicted, his proximity to convicted bureaucrats raises eyebrows.
* **Land and Real Estate Mafia**: Served in roles that allegedly facilitated cartel-friendly clearances in Ayodhya, Lucknow.
* **Media Co-option Allegations**: Handled press suppressions during police brutality episodes (e.g., Hathras).

---

## STRATEGIC ASSESSMENT

| Domain                    | Risk Level | Comments                                                           |
| ------------------------- | ---------- | ------------------------------------------------------------------ |
| Political Bias            | Low        | Seen as non-ideological, serves any government                     |
| Bureaucratic Capture      | High       | Deep influence across UP IAS, IPS, and lower administration        |
| Corporate Influence       | High       | Close to high-value investors and builders                         |
| Criminal Nexus            | Moderate   | No formal proof, but circumstantial links to land mafia            |
| Intelligence Agency Links | Moderate   | May act as proxy; no adverse record despite high-sensitivity roles |
| Legal Vulnerability       | Low        | No FIRs, CBI/ED probes                                             |

---

## NETWORK MAP — UTTAR PRADESH

**Political Connections:**

* **Yogi Adityanath** (BJP CM) — close administrative ally since 2017
* **Akhilesh Yadav** (SP) — retained during SP regime, still attends personal functions
* **Mayawati** (BSP) — retained key portfolios under her rule
* **Aradhna Mishra**, **Satish Mishra** — Congress and BSP leaders present at son's wedding

**IAS/Bureaucracy Network:**

* **Durga Shakti Nagpal** (Land and Revenue) — linked during anti-mafia operations
* **Alok Kumar** (Home Department) — coordination on Ayodhya development
* **Avnish Awasthi** (former ACS, Home) — collaborated on CAA-related public messaging

**IPS/Police Network:**

* **Om Prakash Singh** (former DGP) — coordinated on anti-CAA protest responses
* **Hitesh Chandra Awasthi** — during Hathras incident narrative control
* **Praveen Kumar**, **Rajeev Sabharwal** — information flow management on ground

**Media / PR / Narrative Management:**

* Senior Editors of **Amar Ujala**, **Dainik Jagran**, **ABP**, **News18**, **Doordarshan**
* PR/Ad Agencies with known proximity to the CM Office and Sehgal's office (identities redacted)

**Corporate Ties (Strategic):**

* **Mukesh Ambani (Reliance)** — participated in UP Investors Summit
* **Gautam Adani (Adani Group)** — investments in logistics, warehousing in UP
* **Ajeet Kumar (Lodha Group)** — informal presence in real estate corridor talks

**Religious Trusts / Events:**

* Akhil Bharatiya Akhada Parishad — Kumbh coordination
* Ayodhya Ram Mandir Trust — cultural events and media narrative facilitation

---

## CONCLUSION

Navneet Sehgal is a rare figure in Indian bureaucracy—a **cross-party survivor**, **media manipulator**, and **fixer-operator**. While not a deep state "supreme commander," he is clearly a **top-tier node in the informal governance lattice**—connecting politicians, bureaucrats, corporates, and possibly intelligence agencies, through plausible deniability and narrative control.

---

**RECOMMENDATIONS (For Investigative, Legal or Strategic Use)**

* Track current alliances within Prasar Bharati vis-à-vis 2024 elections.
* Investigate procurement and clearance processes during ODOP and tourism corridor phases.
* Analyze his relationships with media owners and IPS officers during riot/law-and-order flare-ups.
* Map his phone/email metadata with real estate lobbies between 2016–2020.

---

*End of Dossier*
