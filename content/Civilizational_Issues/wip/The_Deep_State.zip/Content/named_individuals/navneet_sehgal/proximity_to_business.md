# Proximity to Corporate and Business Interests

## Question
proximity to corporates /business houses

Navneet Sehgal’s **proximity to corporate and business interests** has long been noted by bureaucratic observers and political insiders in Uttar Pradesh. While not directly accused of corporate favoritism in court, his **roles, actions, and access** paint a picture of a bureaucrat who has **closely engaged with India Inc.** in ways that align with **both governance and political agendas**.

Here is a detailed breakdown:

---

## **Key Indicators of Proximity to Business Houses**

## **Industrial Promotion & Investment Roles**

* **Led the “Invest UP” initiative** under CM Yogi Adityanath, a platform to attract FDI and large domestic investments.
* Instrumental in **UP Investors Summit (2018)** which brought in major corporate players:

  * Reliance (Mukesh Ambani), Adani Group, Tata, Birla, Infosys, and others.
* As **Chairman of Udyog Bandhu**, he was the **interface between government and business**, handling grievances, land clearances, and investment facilitation.

**Implication**: Built a **direct communication channel** with India's largest business conglomerates.

---

## **One District One Product (ODOP) Scheme**

* The flagship MSME scheme often involved **public-private partnerships** and collaboration with export houses, textile magnates, and local industrialists.
* Key in **branding, certification, and logistics negotiations** — areas where proximity to logistics firms and corporate exporters was crucial.

**Implication**: Gained **preferential access** to decision-makers in sectors like textiles, handicrafts, logistics, and e-commerce.

---

## **Media and Advertisement Spend**

* As **Principal Secretary (Information)**, Sehgal controlled **hundreds of crores of state advertisement budgets**.
* Allegations (though never formally pursued) have included:

  * **Funneling large ad contracts** to preferred media houses.
  * Influencing editorial positioning through budget leverage.

**Implication**: Built strategic alliances with **media conglomerates**, many of whom are corporate-funded.

---

## **Tourism, Culture & Infrastructure**

* Oversaw **Ayodhya tourism development**, **Kumbh Mela logistics**, and **heritage circuit funding**.
* These projects saw large contracts awarded to:

  * EPC contractors
  * Hospitality chains
  * Infrastructure players

**Implication**: **Influence over tenders** made him a key contact point for companies eyeing public-private partnerships.

---

## **Post-Retirement Appointment: Prasar Bharati**

* As **Chairman of India's public broadcaster**, he is now in a position to interface with:

  * Large advertising networks
  * OTT platforms
  * Corporate content producers
* Corporate-government-media linkages **often converge at Prasar Bharati** in the form of event sponsorships, content partnerships, and lobbying.

---

## **Soft Allegations / Insider Views**

* Unofficial reports and senior bureaucrats have suggested:

  * He had **back-channel influence in land clearances**, especially industrial clusters.
  * Was seen as **"business-friendly"** in the **Ambani-Adani era** of BJP governance.
  * Some whispers of **preferential access granted to select real estate players** in Lucknow and Ayodhya zones.

**No CBI or ED case** has been initiated against him, indicating either:

* A **clean administrative record**, or
* **Strong political insulation** due to bipartisan goodwill and strategic value.

---

## **Strategic Summary**

| Aspect                         | Observation                                                              |
| ------------------------------ | ------------------------------------------------------------------------ |
| Corporate Relations            | Deep engagement across infrastructure, media, MSMEs, and tourism sectors |
| Investment Facilitation Roles  | Controlled platforms used by India’s top 50 corporate groups             |
| Tendering and Budget Oversight | Oversaw large spend portfolios (ads, infrastructure, tourism)            |
| Regulatory Influence           | Seen as a “green channel” bureaucrat by business circles                 |
| Legal Record                   | Clean – no formal investigations, but under watchful public scrutiny     |

---

Would you like me to **map specific corporate connections or beneficiaries** during his tenure for a risk/power network analysis?
