# Navneet Sehgal

## Question
Prasar Bharati
Ex-IAS officer Navneet Sehgal’s political network
Former IAS officer Navneet Sehgal, currently chairman of Prasar Bharati, is renowned for his extensive political network in Uttar Pradesh. This was once again evident at his son’s wedding reception in Lucknow this week. Among the distinguished attendees were UP Chief Minister Yogi Adityanath, Samajwadi Party chief Akhilesh Yadav, Bahujan Samaj Party general secretary Satish Mishra, and Congress Legislature Party leader Aradhna Mishra, alongside numerous other prominent figures.

what is Prasar Bharti and who is Sehgal


Here is a structured breakdown of **Navneet Sehgal's roles, influence, and controversies** during his career as an IAS officer:

---

##  **Career Overview**

* **Batch/Service**: 1988 batch, **Uttar Pradesh cadre**, Indian Administrative Service (IAS)
* **Reputation**: Known as a **media-savvy bureaucrat**, often trusted with **public relations**, **information**, and **culture-related** portfolios.

---

##  **Key Positions Held**

1. **Principal Secretary (Information)** – UP Government

   * Managed the state's **public relations**, government messaging, and media outreach.
   * Instrumental in the **rebranding efforts** of successive state governments (SP and BJP).

2. **Principal Secretary (Tourism, Culture & Religious Affairs)**

   * Oversaw major tourism initiatives, such as Kumbh Mela preparations and Ayodhya-related events.

3. **Principal Secretary (MSME & Export Promotion)**

   * Played a crucial role in **One District One Product (ODOP)** scheme under CM Yogi Adityanath.
   * Promoted small and medium enterprises and export clusters.

4. **Chairman, Udyog Bandhu**

   * Key investment promotion body in UP; liaised with industry.

5. **Chairman & MD of UP State Road Transport Corporation (UPSRTC), UP State Industrial Development Corporation (UPSIDC)** – Managed state transport and industrial development infrastructure.

6. **Chairman, Prasar Bharati (Post-retirement)**

   * Appointed after retirement in 2022, heading India's apex public broadcasting organization.

---

##  **Political Connectivity**

* **Unusually close ties across party lines**, having served under:

  * **Mulayam Singh Yadav** and **Akhilesh Yadav** (Samajwadi Party)
  * **Mayawati** (Bahujan Samaj Party)
  * **Yogi Adityanath** (BJP)
* This rare continuity has **fueled speculation** about his political capital and lobbying strength.
* The high-profile political presence at his son’s wedding (Yogi, Akhilesh, Aradhna Mishra, Satish Mishra) reflects his **cross-party influence**.

---

## ⚠️ **Controversies and Allegations**

1. **NRHM Scam Association**

   * During the massive **National Rural Health Mission (NRHM) scam** in UP (2009–2011), where several officials were implicated, **Sehgal's name surfaced in media reports**.
   * **No formal charges** were filed against him; he denied any wrongdoing and was later reinstated in key roles.

2. **Frequent Transfers**

   * He faced multiple **transfers and reappointments**, indicating both trust and turbulence in bureaucratic-political equations.

3. **Perceived Bias in Media Handling**

   * As Principal Secretary (Information), he was accused by critics of **favoring certain media houses** and manipulating narratives to suit ruling dispensations.

---

##  **Key Strengths**

* **Crisis Manager**: Frequently brought in to manage **sensitive portfolios** during transitions or crises.
* **Public Branding**: Known for strategic messaging and **image-building campaigns**, including UP Investors Summit and Kumbh Mela promotions.
* **Administrative Versatility**: Managed portfolios ranging from media and tourism to MSME and transport—rare breadth of experience.

---

## **Summary Assessment**

| **Aspect**                | **Assessment**                                                               |
| ------------------------- | ---------------------------------------------------------------------------- |
| Administrative Skill      | High – successfully ran complex portfolios                                   |
| Political Acumen          | Exceptional – rare bipartisan acceptance                                     |
| Controversial Record      | Mixed – clean legal record, but alleged links to irregularities and lobbying |
| Post-Retirement Influence | Strong – appointment as Prasar Bharati Chairman confirms lasting influence   |

---
